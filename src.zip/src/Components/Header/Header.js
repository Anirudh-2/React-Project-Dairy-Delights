import './Header.css';
import NavBar from './Navbar';
import Content from './Content';
import React from 'react';
import { Context } from '../../App'; // Adjust the import path to access App.js

export default function Header({ setFilteredProduct }) {
    return (
        <Context.Consumer>
            {({ isLogin, user, setUser, login, logOut }) => (
                <div className='Header'>
                    <Content setFilteredProduct={setFilteredProduct} />
                    <NavBar setFilteredProduct={setFilteredProduct} />
                </div>
            )}
        </Context.Consumer>
    );
}
