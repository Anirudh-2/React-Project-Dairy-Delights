import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Card, CardContent, CardActions, Button, TextField, Typography, Select, MenuItem, FormControl, InputLabel } from "@mui/material";

export default function SignUp() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    id: "",
    password: "",
    name: "",
    address: "",
    mobileno: "",
    role: "ROLE_USER" // Default to ROLE_USER
  });

  const [error, setError] = useState(""); // To store error messages

  const inputEnter = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const registerUser = async (e) => {
    e.preventDefault();
    try {
      const url = `http://localhost:3000/users`;
      const checkEmailResponse = await checkEmail(); // Call the checkEmail function
      if (checkEmailResponse.length === 0) {
        const response = await axios.post(url, formData);
        console.log(response);
        alert("Successfully registered");
        navigate("/login");
      } else {
        setError("EmailId must be unique");
      }
    } catch (err) {
      console.error(err);
      setError("Registration failed! Please try again.");
    }
  };

  const checkEmail = async () => {
    try {
      const url = `http://localhost:3000/users/?id=${formData.id}`;
      const response = await axios.get(url);
      return response.data;
    } catch (err) {
      console.error(err);
      return []; // Return an empty array on error
    }
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
      <Card style={{ width: "400px", padding: "20px" }}>
        <CardContent>
          <Typography variant="h5" component="h2" gutterBottom>
            Signup Form
          </Typography>
          {error && <p style={{ color: "red" }}>{error}</p>}
          <form onSubmit={registerUser}>
            <TextField
              label="Email ID"
              type="text"
              name="id"
              value={formData.id}
              onChange={inputEnter}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={inputEnter}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Name"
              type="text"
              name="name"
              value={formData.name}
              onChange={inputEnter}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Address"
              type="text"
              name="address"
              value={formData.address}
              onChange={inputEnter}
              fullWidth
              margin="normal"
              required
            />
            <TextField
              label="Mobile No."
              type="text"
              name="mobileno"
              value={formData.mobileno}
              onChange={inputEnter}
              fullWidth
              margin="normal"
              required
            />
            
            {/* Dropdown for Role Selection */}
            <FormControl fullWidth margin="normal">
              <InputLabel id="role-label">Role</InputLabel>
              <Select
                labelId="role-label"
                name="role"
                value={formData.role}
                onChange={inputEnter}
                required
              >
                <MenuItem value="ROLE_USER">User</MenuItem>
                <MenuItem value="ROLE_ADMIN">Admin</MenuItem>
              </Select>
            </FormControl>
            
            <CardActions>
              <Button type="submit" variant="contained" color="primary" fullWidth>
                Signup
              </Button>
            </CardActions>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
