import './Content.css';
import { useNavigate } from 'react-router-dom';
import { useContext, useState } from 'react';
import { Context } from '../../App'; // Adjust the import path to access App.js

export default function Content({ setFilteredProduct }) {
    const [searchTerm, setSearchTerm] = useState("");
    const { logOut, isLogin, login } = useContext(Context); 

    const navigate = useNavigate();

    const clickEvent = (move) => {
        navigate(move);
        console.log(move);
    };

    const handleInputChange = (e) => {
        setSearchTerm(e.target.value);
        setFilteredProduct(e.target.value);
    };

    const clearSearch = () => {
        setSearchTerm("");
        setFilteredProduct("");
    };

    return (
        <div className='container'>
            <div className='logo-section'>
                <img src="./dairies/dairy2.jpg" alt="Dairy Delights Logo" className="img" />
                <div className='text-section'>
                    <h2 className="h">Dairy Delights!</h2>
                    <p className="p">Celebrate your moments</p>
                </div>
            </div>
            <div className='auth-search-container'>
                <div className='search-container'>
                    <input
                        type="text"
                        value={searchTerm}
                        onChange={handleInputChange}
                        placeholder="Search products..."
                        className='search-bar'
                    />
                    {searchTerm && (
                        <button onClick={clearSearch} className='cancel-icon'>
                            &#10006; {/* Cross icon for cancel */}
                        </button>
                    )}
                </div>
                <div className='auth-buttons'>
                    {!isLogin ? (
                        <>
                            <button className='auth-button'  onClick={() => clickEvent('/login')}>Login</button>
                            <button className='auth-button' onClick={() => clickEvent('/signUp')}>Sign Up</button>
                        </>
                    ) : (
                        <button className='auth-button' onClick={logOut}>Logout</button>
                    )}
                </div>
            </div>
        </div>
    );
}
