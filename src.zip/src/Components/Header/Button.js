
import  './Button.css';
export default function Button({setFilteredProduct}){
    return(
        <div>
        <button className="button" onClick={()=>setFilteredProduct("")}>ALL</button>
          <button className="button"  onClick={()=>setFilteredProduct("milk")}   >MILK</button>
          <button className="button"  onClick={()=>setFilteredProduct("butter")} >BUTTER</button>
          <button  className="button" onClick={()=>setFilteredProduct("buttermilk")} >BUTTER MILK</button>
          <button className="button"  onClick={()=>setFilteredProduct("cheese")}>CHEESE</button>
          <button  className="button"  onClick={()=>setFilteredProduct("curd")}>CURD</button>
          <button  className="button"  onClick={()=>setFilteredProduct("cream")}>CREAM</button>
          <button  className="button"  onClick={()=>setFilteredProduct("yogurt")}>YOGURT</button>
          <button  className="button"  onClick={()=>setFilteredProduct("paneer")}>PANEER</button>
            
        </div>

    );
}