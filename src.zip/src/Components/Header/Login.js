import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { Context } from "../../App";
import { Card, CardContent, Typography, TextField, Button, CircularProgress, FormControlLabel, Checkbox } from '@mui/material';

export default function Login({ addUser }) {
  const { login, setUser } = useContext(Context);
  const navigate = useNavigate();
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  const [formData, setFormData] = useState({
    emailid: "",
    password: "",
  });

  const inputEnter = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const loginCheck = async (e) => {
    e.preventDefault();
    setError(null);

    // Validation before making the API call
    if (!formData.emailid || !formData.password) {
      setError("Please enter both email and password");
      return;
    }

    setLoading(true); // Show loading spinner
    try {
      // Check if the user is the default admin
      if (formData.emailid === "admin@gmail.com" && formData.password === "admin123") {
        const adminUser = {
          id: "admin@gmail.com",
          password: "admin123",
          role: "ROLE_ADMIN",
        };
        setUser(adminUser);
        login();
        navigate('/admin');
        return;
      }

      // Regular user check
      const url = `http://localhost:3000/users/?emailid=${formData.emailid}`;
      const response = await axios.get(url);

      if (response.data.length > 0) {
        const resultUserData = response.data[0];
        if (resultUserData.password === formData.password) {
          // Set user role based on login
          setUser(resultUserData);
          login();

          // Navigate based on user role
          if (resultUserData.role === "ROLE_ADMIN") {
            navigate('/admin');
          } else if (resultUserData.role === "ROLE_USER") {
            navigate('/user');
          } else {
            setError("Unrecognized role, cannot navigate");
          }
        } else {
          setError('Invalid password');
        }
      } else {
        // Show an error if no user was found with the provided email
        setError('User does not exist. Please sign up.');
      }
    } catch (err) {
      console.error(err);
      setError('An error occurred. Please try again later.');
    } finally {
      setLoading(false); // Hide loading spinner
    }
  };

  return (
    <div
      style={{
        width: "100%",
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#d1b279",
      }}
    >
      <Card
        style={{
          width: "400px",
          backgroundColor: "rgba(255, 255, 255, 0.8)", // transparent background
          backdropFilter: "blur(10px)", // optional: blur effect
          boxShadow: "0 4px 20px rgba(0,0,0,0.2)",
        }}
      >
        <CardContent>
          <Typography variant="h4" align="center" gutterBottom>
            Login Form
          </Typography>
          <form onSubmit={loginCheck}>
            <TextField
              fullWidth
              label="Email ID"
              name="emailid"
              value={formData.emailid}
              onChange={inputEnter}
              variant="outlined"
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={inputEnter}
              variant="outlined"
              margin="normal"
              required
            />

            {/* Remember Me checkbox */}
            <FormControlLabel
              control={
                <Checkbox
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  name="rememberMe"
                  color="primary"
                />
              }
              label="Remember Me"
            />

            {/* Show error message if there's an error */}
            {error && (
              <Typography color="error" align="center">
                {error}
              </Typography>
            )}

            {/* Loading spinner when the form is being submitted */}
            {loading ? (
              <div style={{ display: "flex", justifyContent: "center", margin: "10px" }}>
                <CircularProgress />
              </div>
            ) : (
              <Button
                type="submit"
                variant="contained"
                color="primary"
                style={{ width: "100%", height: "40px", fontSize: "1.25em" }}
              >
                Login
              </Button>
            )}
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
