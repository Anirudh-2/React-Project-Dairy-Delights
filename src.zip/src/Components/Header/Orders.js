import axios from "axios";
import { useEffect, useState } from "react";

export default function Orders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3000/orders")
      .then(response => setOrders(response.data))
      .catch(error => console.log(error.message));
  }, []);

  return (
    <div>
      <h2>User Orders</h2>
      {orders.map(order => (
        <div key={order.id} style={{ backgroundColor: "lightgray", margin: "10px", padding: "10px" }}>
          <p>First Name: {order.firstName}</p>
          <p>Address: {order.address}</p>
          <p>Product Name: {order.productName}</p>
          <p>City: {order.city}</p>
          <p>Contact: {order.contact}</p>
          <p>Delivery Date: {order.deliveryDate}</p>
          <p>Quantity: {order.quantity}</p>
        </div>
      ))}
    </div>
  );
}
