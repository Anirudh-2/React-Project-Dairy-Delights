import axios from "axios";
import { useEffect, useState } from "react";
import ProductManagement from "./ProductManagement";
import Orders from "./Orders";

export default function Admin() {
  const [view, setView] = useState("products");

  const handleViewChange = (newView) => {
    setView(newView);
  };

  return (
    <div>
      <button onClick={() => handleViewChange("products")}>Manage Products</button>
      <button onClick={() => handleViewChange("orders")}>View Orders</button>
  
      {view === "products" ? <ProductManagement /> : <Orders />}
    </div>
  );
  
}
