import './Navbar.css';
import Button from './Button'; // Assuming Button is in the same directory

export default function Navbar({ setFilteredProduct }) {
    return (
        <nav className="navbar">
            {/* Pass setFilteredProduct to Button */}
            <Button setFilteredProduct={setFilteredProduct} />
        </nav>
    );
}
