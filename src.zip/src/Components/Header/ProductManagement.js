import axios from "axios";
import { useState, useEffect } from "react";
import './ProductManagement.css'; // Import your CSS file for styles

export default function ProductManagement() {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: "", price: "", category: "", image: "" });

  useEffect(() => {
    axios.get("http://localhost:3000/products")
      .then(response => setProducts(response.data))
      .catch(error => console.log(error.message));
  }, []);

  const addProduct = () => {
    axios.post("http://localhost:3000/products", newProduct)
      .then(response => {
        setProducts([...products, response.data]);
        setNewProduct({ name: "", price: "", category: "", image: "" }); // Reset form
      })
      .catch(error => console.log(error.message));
  };
  
  const deleteProduct = (id) => {
    axios.delete(`http://localhost:3000/products/${id}`)
      .then(() => setProducts(products.filter(product => product.id !== id)))
      .catch(error => console.log(error.message));
  };

  return (
    <div>
      <h2>Product Management</h2>
      <div>
        <input 
          type="text" 
          placeholder="Product Name" 
          value={newProduct.name} 
          onChange={e => setNewProduct({ ...newProduct, name: e.target.value })}
        />
        <input 
          type="text" 
          placeholder="Price" 
          value={newProduct.price} 
          onChange={e => setNewProduct({ ...newProduct, price: e.target.value })}
        />
        <input 
          type="text" 
          placeholder="Category" 
          value={newProduct.category} 
          onChange={e => setNewProduct({ ...newProduct, category: e.target.value })}
        />
        <input 
          type="text" 
          placeholder="Image URL" 
          value={newProduct.image} 
          onChange={e => setNewProduct({ ...newProduct, image: e.target.value })}
        />
        <button onClick={addProduct}>Add Product</button>
      </div>
      <div className="product-list">
        {products.map(product => (
          <div className="product-card" key={product.id}>
            <img src={product.image} alt={product.name} className="product-image" />
            <div className="product-info">
              <h4>{product.name}</h4>
              <p>Price: {product.price}</p>
              <p>Category: {product.category}</p>
              <button onClick={() => deleteProduct(product.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
