import './MainContent.css';
import MainList from './MainList';
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function MainContent() {
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3000/products'); // Adjust this URL based on your API
        setFilteredData(response.data); // Assuming your response data is in the correct format
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>; // Show loading while data is being fetched
  }

  if (!Array.isArray(filteredData) || filteredData.length === 0) {
    return <div>No data available.</div>; // Optional: handle no data case
  }

  return (
    <div className='Display'>
      <div className='Main'>
        <div className='Child'>
          <h1>Dairy Delights Delivery</h1>
          <p className='pp'>Farm To Home</p>
          <button className="Button">Shop Now</button>
        </div>
        <img src="./dairies/dairy.jpg" className="logo" alt="Dairy" />
      </div>
      <div className='CardContainer'>
        {filteredData.map((c) => <MainList abc={c} key={c.id} />)}
      </div>
    </div>
  );
}
