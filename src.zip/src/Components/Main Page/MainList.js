import './MainList.css';
import { Link } from 'react-router-dom';

export default function MainList({ abc }) {
    return (
        <Link to={`/detail/${abc.id}`} className='card-link'>
            <div className='card'>
                <img className="img" src={`/${abc.image}`} alt={abc.name} />
                <div className='Name'>{abc.productName}</div> {/* Product name */}
                <div className='Price'>${abc.price}</div>
            </div>
        </Link>
    );
}
