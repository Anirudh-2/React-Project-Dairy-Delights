import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './DetailPage.css';

function DetailPage() {
  const { id } = useParams();
  const [cake, setCake] = useState(null);
  const [error, setError] = useState(null);
  const [orderData, setOrderData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    deliveryDate: '',
    quantity: '',
    weight: '500g',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    description: '',
  });

  useEffect(() => {
    const url = `http://localhost:3000/products/${id}`;
    axios.get(url)
      .then(response => {
        setCake(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setError(error);
      });
  }, [id]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setOrderData({ ...orderData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3000/orders', {
        ...orderData,
        productName: cake.name, // Include the cake name in the order
      });
      console.log('Order placed successfully:', response.data);
      alert('Order placed successfully!');
      // Reset form after submission
      setOrderData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        deliveryDate: '',
        quantity: '',
        weight: '500g',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        description: '',
      });
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order. Please try again.');
    }
  };

  if (error) return <div>Error fetching data: {error.message}</div>;
  if (!cake) return <div>Loading...</div>;

  const imageUrl = `../${cake.image}`;

  return (
    <div className="detail-container">
      <div className="detail-card">
        <img src={imageUrl} alt={cake.name} className="detail-img" />
        <h2>Description</h2>
        <div className="Description">{cake.description}</div>
        <h2>Delivery Information</h2>
        <div className="DeliveryInfo">{cake.deliveryInfo}</div>
        <h2>Care Instructions</h2>
        <div className="CareInstructions">{cake.careInstructions}</div>
      </div>
      <div className="detail-form">
        <h2 className="product-name">{cake.name}</h2>
        <div className="Rating">Rating: {cake.rating}</div>
        <div className="Price">Price: {cake.price}</div>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <label>First Name* <input type="text" name="firstName" value={orderData.firstName} onChange={handleInputChange} required /></label>
            <label>Last Name* <input type="text" name="lastName" value={orderData.lastName} onChange={handleInputChange} required /></label>
          </div>
          <div className="form-row">
            <label>Email* <input type="email" name="email" value={orderData.email} onChange={handleInputChange} required /></label>
            <label>Phone Number* <input type="tel" name="phone" value={orderData.phone} onChange={handleInputChange} required /></label>
          </div>
          <div className="form-row">
            <label>Choose Delivery Date* <input type="date" name="deliveryDate" value={orderData.deliveryDate} onChange={handleInputChange} required /></label>
            <label>Quantity* <input type="number" name="quantity" value={orderData.quantity} onChange={handleInputChange} required /></label>
            <label>Weight* 
              <select name="weight" value={orderData.weight} onChange={handleInputChange} required>
                <option value="500g">500g</option>
                <option value="1kg">1kg</option>
                <option value="2kg">2kg</option>
              </select>
            </label>
          </div>
          <label>Address* <input type="text" name="address" value={orderData.address} onChange={handleInputChange} required /></label>
          <div className="form-row">
            <label>City* <input type="text" name="city" value={orderData.city} onChange={handleInputChange} required /></label>
            <label>State* <input type="text" name="state" value={orderData.state} onChange={handleInputChange} required /></label>
            <label>Zip Code* <input type="text" name="zipCode" value={orderData.zipCode} onChange={handleInputChange} required /></label>
          </div>
          <label>Description <textarea name="description" value={orderData.description} onChange={handleInputChange} required></textarea></label>
          <div className="button-row">
            <button type="reset">Reset</button>
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default DetailPage;
