 import styled from "styled-components";
const Container = styled.div`
  display: flex;
  flex-wrap: wrap;
  background-color: rgb(110, 199, 211);
  margin: 50px 0 20px 0;
  padding: 50px;
`;
const DetailsContainer = styled.div`
  display: grid;
  grid-template-columns: 30% 70%;
  align-items: center;
`;
const Details = styled.p`
  display: flex;
  color: white;
  font-weight: bold;
  font-size: 1.2em;
  font-family: cursive;
  padding: 50px 10px 10px 50px;
`;
const Image = styled.img`
  width: 100%;
  height: auto;
  max-width: 400px;
  max-height: 200px;
`;
const Tag = styled.div`
  background-image: url("./dairies/dairy.jpg");
  background-size: cover;
  padding: 50px;
  display: flex;
  flex-direction: column;
  gap: 20px;
  background-color: rgba(110, 199, 211, 0.5);
`;
const ProductTag = styled.p`
color: darkslategrey;
  font-weight: bold;
  font-size: 1.2em;
  font-family: cursive;
  padding: 10px;
  background: rgba(255, 255, 255, 0.5); /* Light background for blending effect */
  border-radius: 8px; /* Adds a subtle rounded effect */
`;
export default function DashBoard() {
  return (
    <Container>
      <DetailsContainer>
        <Image src="./dairies/dairy2.jpg" />
        <Details>
          {/* " Millions of people around the world rely on a variety of dairy products and foods for a delicious, nutritious way to balance their diet. Whether you rely on milk or yogurt for your overnight oats or cheese on your taco, there are countless ways to enjoy dairy items in your everyday life. "  */}
          'Dairy products are a vital component of many diets around the world, known for their rich nutritional profile and numerous health benefits. These products, which include milk, cheese, yogurt, butter, and cream, are derived from the milk of mammals, primarily cows, but also goats, sheep, and other animals.'
        </Details>
      </DetailsContainer>
      <Tag>
        <ProductTag>
          Milk, cheese, and yoghurt are naturally full of important nutrients such as calcium and protein. The unique package of vitamins and minerals they provide means these dairy products pack some pretty important health benefits.
        </ProductTag>
        <ProductTag>
          In fact, the Australian Dietary Guidelines say that consumption of milk, cheese, and yoghurt is linked to a reduced risk of heart disease, stroke, hypertension, type 2 diabetes, metabolic syndrome, and colorectal cancer – some of the main causes of death in Australia.
        </ProductTag>
        <ProductTag>
        These probiotics can help maintain a healthy balance of gut flora, which is increasingly recognized as crucial for overall health. Here are some of the key health benefits associated with eating dairy foods.
        </ProductTag>
      </Tag>
    </Container>
  );
}