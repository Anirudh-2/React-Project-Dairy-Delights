import * as React from 'react';
import styled from 'styled-components';
import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Grid from '@mui/material/Grid'; // Ensure this is the only import for Grid
import axios from "axios";
import { useForm } from "react-hook-form";


const Container = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  padding: 20px;
  background-color: #f9e6db;
  margin-top:120px;
  `;

const ItemDetails = styled.div`
  display: flex;
  flex-direction: column;
  background-color: white;
  padding: 20px;
  border-radius: 8px;
`;

const OrderForm = styled.form`
  background-color: white;
  padding: 20px;
  border-radius: 8px;
`;

const ItemImage = styled.img`
  width: 100%;
  height:30%;
  border-radius: 8px;
`;

const Title = styled.h2`

`;

const Description = styled.p`
  margin-top: 0;
`;

const List = styled.ul`
  padding-left: 20px;
`;

const ListItem = styled.li`
  margin-bottom: 10px;
`;

const FormGroup = styled.div`
  display: flex;
  justify-content:center;
  flex-wrap:wrap;
  margin-bottom: 15px;

`;

const StyledTextField = styled(TextField)`
  margin-bottom: 15px;
`;

const SubmitButton = styled.button`
  background-color: rgb(185, 165, 52);;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
`;

const ResetButton = styled.button`
  background-color: #ff6b6b;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
  margin-right: 20px;
`;

// const weightOptions = ["2kg", "1kg", "500gm", "250gm", "6 pieces", "4 pieces"];

export default function OrderPage() {
  const { id } = useParams();
   console.log(id);
  const [products, setCake] = useState({});
  const { register, handleSubmit, reset, trigger, formState: { errors } } = useForm({
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      quantity: '',
      weight: '',
      address: '',
      city: '',
      state: '',
      zip: '',
      description: '',
      deliveryDate: '', 
      orderName :products.productName||" "
    }
  });

  useEffect(() => {
    async function fetchData() {
      try {
        const url = `http://localhost:3000/products/${id}`;
        const response = await axios.get(url);
        setCake({
          ...response.data,
          image: "/" + response.data.image
        });
console.log(products);
    reset({
        ...response.data, 
        orderName: response.data.productName || " "
    });
      } catch (error) {
        console.log("Error fetching data", error);
      }
    }
    fetchData();
  }, [id,reset]);

  const onSubmit = async (data) => {
    try{
      const orderUrl="http://localhost:3000/orders";
      let responseForm= await axios.post(orderUrl,data);
      console.log("Form data:", responseForm);
      onReset();
    }catch(error){
      console.log("error in place order"+error.message);
    }
  };

  const onReset = () => {
    reset();
  };

  return (
    <Container>
      <ItemDetails>
        {products ? (
          <>
            <ItemImage src={products.image} alt={products.name} />
            <h3>Description</h3>
            <Description>{products.description}</Description>
            <h4>Delivery Information</h4>
            <List>
              <ListItem>Every  products we offer is handcrafted and since each chef has their own way of baking and designing a products, there might be slight variations in the product in terms of design and shape.</ListItem>
              <ListItem>Since products are perishable in nature, we attempt delivery of your order only once. The delivery cannot be redirected to other addresses.</ListItem>
            </List>
            <h4>Care Instructions</h4>
            <List>
              <ListItem>Store cream products in a refrigerator. Fondant products should be stored in an air-conditioned environment.</ListItem>
              <ListItem>Slice and serve the products at room temperature and make sure it is not exposed to heat.</ListItem>
              <ListItem>Use a serrated knife to cut a fondant products.</ListItem>
              <ListItem>The products should be consumed within 24 hours.</ListItem>
            </List>
          </>
        ) : (
          <p>Product not found</p>
        )}
      </ItemDetails>
      <OrderForm onSubmit={handleSubmit(onSubmit)}>
        <div style={{display:"flex", alignItems:"center",gap:"20px"}}>
        <Title>{products.productName}</Title>
        <p>{products.rating}</p>
        </div>
        <p>Rs {products.price}</p>
        <p>Fill Details to Place Order</p>
        
        <Box component="div"
          sx={{
            '& .MuiTextField-root': { m: 1, width: '25ch' },
          }} noValidate autoComplete="off"
        >
          <FormGroup>
          <Grid container spacing={2}>
         <Grid item xs={4} >
            <StyledTextField required id="firstName" label="First Name"  {...register("firstName",
               { required: "First Name is required" })} helperText={errors.firstName?.message} 
               style={{width:"230px"}} error={Boolean(errors.firstName)} 
               onBlur={() => trigger("firstName")} variant="standard"
            />
            </Grid>
            <Grid item xs={4} >
            <StyledTextField required id="lastName" label="Last Name"
              {...register("lastName", { required: "Last Name is required" })}
              helperText={errors.lastName?.message} error={Boolean(errors.lastName)} variant="standard"
              style={{width:"230px"}} onBlur={() => trigger("lastName")}
            />
           </Grid>
           <Grid item xs={4} > 
            <StyledTextField required id="email" label="Email" {...register("email", 
            {required: "Email is required", pattern: {value: /^\S+@\S+$/i,
              message: "Enter valid email address"}})}helperText={errors.email?.message}
              error={Boolean(errors.email)} variant="standard" style={{width:"230px"}}
              onBlur={() => trigger("email")}
            />
            </Grid>
           <Grid item xs={4} >
            <StyledTextField required id="phone" label="Phone"{...register("phone", 
            { required: "Phone is required", pattern: {value: /^[789]\d{9}$/,
                message: "Valid phone contains 10 digits and starts with 7/8/9" }
              })} helperText={errors.phone?.message} error={Boolean(errors.phone)} variant="standard"
              style={{width:"230px"}} onBlur={() => trigger("phone")}
            />
            </Grid>
            <Grid item xs={4} >
            <StyledTextField required id="deliveryDate" label="Delivery Date" style={{width:"150px"}}
              type="date" {...register("deliveryDate", { required: "Delivery Date is required" })}
              helperText={errors.deliveryDate?.message} error={Boolean(errors.deliveryDate)} 
              variant="standard" InputLabelProps={{ shrink: true, }} 
              onBlur={() => trigger("deliveryDate")}
            />
            </Grid>                 
            <Grid item xs={4} >     
              <StyledTextField required id="quantity" label="Quantity" style={{width:"150px"}}
              {...register("quantity", { required: "Quantity is required" })}
              helperText={errors.quantity?.message}error={Boolean(errors.quantity)} variant="standard"
              onBlur={() => trigger("quantity")}
            />
            </Grid>
            
            {/* <TextField select style={{width:"150px"}} label="Weight/Pieces" id="weight"
              {...register("weight")} variant="standard" onBlur={() => trigger("weight")}
            >
              {weightOptions.map((option) => (
                <MenuItem key={option} value={option}>
                  {option}
                </MenuItem>
              ))}
            </TextField><br/> */}
            <Grid item xs={4} >
            <StyledTextField required style={{width:"300px"}} id="address" label="Address"
              {...register("address", { required: "Address is required" })}
              helperText={errors.address?.message} error={Boolean(errors.address)} variant="standard"
              onBlur={() => trigger("address")}
            />
            </Grid>
            <Grid item xs={4} >            
              <StyledTextField required style={{width:"150px"}} id="city" label="City" 
              onBlur={() => trigger("city")} {...register("city", { required: "City is required" })}
              helperText={errors.city?.message} error={Boolean(errors.city)} variant="standard"
            /></Grid><Grid item xs={4} >
            <StyledTextField required id="state" style={{width:"150px"}} label="State"
              onBlur={() => trigger("state")} {...register("state", { required: "State is required" })}
              helperText={errors.state?.message} error={Boolean(errors.state)} variant="standard"
            />
            </Grid><Grid item xs={4} >
            <StyledTextField required id="zip" style={{width:"150px"}} label="Zip Code"
              {...register("zip", { required: "Zip Code is required", pattern: { value: /^\d{6}$/,
                  message: "Valid zipcode should have 6 digits" }
              })} helperText={errors.zip?.message} error={Boolean(errors.zip)} variant="standard"
              onBlur={() => trigger("zip")}
            />
            </Grid><Grid item xs={4} >
            <StyledTextField id="description" label="Description" style={{width:"480px"}}
            {...register("description")} variant="standard"
            />
           </Grid>
           </Grid>
          </FormGroup><br/>
        </Box>
        <div style={{margin:"5px"}}>
          <ResetButton type="button" onClick={onReset}>RESET</ResetButton>
          <SubmitButton type="submit">SUBMIT</SubmitButton>
        </div>
        
      </OrderForm>
    </Container>
  );
}
