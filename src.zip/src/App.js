import './App.css';
import Header from './Components/Header/Header';
import axios from 'axios';
import { useState, useEffect, createContext } from 'react';
import MainContent from './Components/Main Page/MainContent';
import Footer from './Components/Footer/Footer';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import DetailPage from './Components/Main Page/DetailPage';
import DashBoard from './Components/Main Page/DashBoard';
import Login from './Components/Header/Login';
import SignUp from './Components/Header/SignUp';
import Admin from './Components/Header/Admin';

export const Context = createContext();

function App() {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState(null);
  const [details, setDetails] = useState("");
  const [filteredProduct, setFilteredProduct] = useState("");
  const [isLogin, setLogin] = useState(false);
  const [user, setUser] = useState(undefined);

  const filteredItems = (filteredProduct, products) => {
    if (filteredProduct !== "") {
      return products.filter(item =>
        item.category.toLowerCase().includes(filteredProduct.toLowerCase())
      );
    } else {
      return products;
    }
  };

  useEffect(() => {
    const url = "http://localhost:3000/products";
    axios.get(url)
      .then((response) => {
        setProducts(response.data);
      })
      .catch(error => {
        console.error("There was an error fetching the data!", error);
        setError(error);
      });
  }, []);

  useEffect(() => {
    const url = "http://localhost:3000/products";
    axios.get(url)
      .then((response) => setDetails(response.data))
      .catch(error => console.log(error.message));
  }, []);

  const login = () => {
    console.log("User logging in:", user); // Check user context
    setLogin(true);
};

  const logOut = () => {
    setLogin(false);
    removeUser();
  };
  
  const addUser = (user) => {
    setUser(user);
    console.log("User logged in:", user); // Added log to check user object
  };

  const removeUser = () => setUser(undefined);

  // Updated Protect component to handle user roles
  function Protect({ children, allowedRoles }) {
    if (!isLogin) {
      return <Navigate to="/login" />;
    }

    // Logging role for debugging
    console.log("Current user role:", user?.role);

    // If user is logged in and their role is one of the allowed roles
    if (allowedRoles.includes(user?.role)) {
      return children;
    }

    // Admin should have access to both user and admin routes
    if (user?.role === "ROLE_ADMIN") {
      return children;
    }

    // Redirect if the role doesn't match
    return <Navigate to="/" />;
  }

  const displayedProducts = filteredItems(filteredProduct, products);

  return (
    <Context.Provider value={{ isLogin, user, setUser, login, logOut }}>
      <div className="App">
        {error ? (
          <div>Error fetching data: {error.message}</div>
        ) : (
          <Router>
            <Header setFilteredProduct={setFilteredProduct} />
            <Routes>
              <Route path="/" element={<DashBoard />} />
              <Route path="/user" element={<Protect allowedRoles={['ROLE_USER', 'ROLE_ADMIN']}><MainContent filteredData={displayedProducts} /></Protect>} />
              <Route path="/detail/:id" element={<DetailPage />} />
              <Route path="/login" element={<Login addUser={addUser} />} />
              <Route path="/signUp" element={<SignUp />} />
              <Route path='/admin' element={<Protect allowedRoles={['ROLE_ADMIN']}><Admin /></Protect>} />
            </Routes>
            <Footer />
          </Router>
        )}
      </div>
    </Context.Provider>
  );
}

export default App;
